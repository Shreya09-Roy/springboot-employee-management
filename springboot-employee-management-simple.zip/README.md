# Spring Boot Employee Management (Simple)

A simple Spring Boot project with REST endpoints for Employee CRUD using H2 in-memory database.

## How to run locally
1. Install Java 11+ and Maven.
2. From project root run:
   ```
   mvn clean package
   java -jar target/springboot-employee-management-1.0.0.jar
   ```
3. API base: http://localhost:8080/api/employees

## Example curl
```
curl http://localhost:8080/api/employees
```
