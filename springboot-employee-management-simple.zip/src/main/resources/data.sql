INSERT INTO employees (first_name, last_name, email, department) VALUES ('Asha', 'Roy', 'asha.roy@example.com', 'Engineering');
INSERT INTO employees (first_name, last_name, email, department) VALUES ('Ravi', 'Kumar', 'ravi.kumar@example.com', 'HR');
